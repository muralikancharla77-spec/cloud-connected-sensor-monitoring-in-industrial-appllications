#include"types.h"
void InitKPM(void);
u32 ColScan(void);
u32 RowCheck(void);
u32 ColCheck(void);
u8 KeyScan(void);
s32 ReadNum(void);
