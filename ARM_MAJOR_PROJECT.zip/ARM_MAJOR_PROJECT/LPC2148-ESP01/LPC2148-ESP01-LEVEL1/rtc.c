#include<LPC21xx.h>
#define FOSC      12000000
#define CCLK  	  5*FOSC
#define PCLK  	  CCLK/4
#define PREINT_VAL ((PCLK/32768)-1)
#define PREFRAC_VAL (PCLK - ((PREINT_VAL + 1) * 32768))

void rtc_init()
{
	PREINT=PREINT_VAL;
  PREFRAC=PREFRAC_VAL;


  //rtc_init(); //initialize all seconds,minute and hour values

  CCR=0x11; //timer started with external clock source

	SEC=20; //Initialized seconds
  MIN=00; //Initialized minutes
  HOUR=12;//Initialized hour
}
