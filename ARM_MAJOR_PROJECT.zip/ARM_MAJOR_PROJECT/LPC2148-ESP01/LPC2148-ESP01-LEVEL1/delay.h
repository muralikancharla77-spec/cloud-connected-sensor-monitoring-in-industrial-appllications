                         /* delay.h */
#ifndef __DELAY_H__
#define __DELAY_H__

#include "types.h"
void delay_ms(u32 dlyMS);
void delay_us(u32 dlyUS);

#endif
