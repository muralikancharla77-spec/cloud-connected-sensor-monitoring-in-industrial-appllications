#include <lpc21xx.h>
#include "pin_function_defines.h"
#include "types.h"

void eint0_isr(void) __irq;
void Enable_EINT0(void);

u8 i_flag;

void eint0_isr(void) __irq
{
	//CPLBIT(IOPIN1,EINT0_LED);//isr activity
	i_flag=1;
	EXTINT=1<<0;//clear flag
	VICVectAddr=0;//dummy write;
}	

void Enable_EINT0(void)
{
	//CFGPIN(PINSEL0,1,FUNC4);
	PINSEL1|=0x15400001;
	VICIntEnable=1<<14;
	VICVectCntl1=0x20|14;
	VICVectAddr1=(unsigned)eint0_isr;
	//EINT0 as EDGE_TRIG
  	EXTMODE=1<<0;	
}	
