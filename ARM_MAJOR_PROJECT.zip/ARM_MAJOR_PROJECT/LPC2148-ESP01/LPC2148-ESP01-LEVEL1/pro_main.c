#include<lpc21xx.h>
#include "types.h"
#include "lcd.h"
#include "delay.h"
#include "esp01.h"
#include "i2c.h"
#include "i2c_eeprom.h"
#include "kpm.h"
#include "uart0.h"
#include "dht11.h"

#define TEMP_ADDR 0x00
#define HUMI_ADDR 0X10
#define I2C_SADDR 0x50

extern u8 i_flag;
u8 r_temp,r_humi,min;

void rtc_init(void);
void Enable_EINT0(void);

void change_setpoint(void)
{
	u8 ch;
	u32 val;
	Write_CMD_LCD(0x01);
	Write_str_LCD("1.TEMP 2. HUMI");
	Write_CMD_LCD(0xC0);
	Write_str_LCD("    3. EXIT   ");
	ch=KeyScan();
	delay_ms(200);
	 while(ColScan()==0);
	switch(ch)
	{
		case '1':Write_CMD_LCD(0x01);
				Write_str_LCD("CHANGE TEMP:");
				val=ReadNum();
				i2c_eeprom_write(I2C_SADDR,TEMP_ADDR,val);
				r_temp=i2c_eeprom_read(I2C_SADDR,TEMP_ADDR);
				Write_str_LCD("TEMP SPOINT CHANGED");
				min=MIN=0;
				delay_ms(1000);
				Write_CMD_LCD(0x01);
				break;
		case '2':Write_CMD_LCD(0x01);
				Write_str_LCD("CHANGE HUMI:");
				val=ReadNum();
				i2c_eeprom_write(I2C_SADDR,HUMI_ADDR,val);
				r_humi=i2c_eeprom_read(I2C_SADDR,HUMI_ADDR);
				Write_str_LCD("HUMI SPOINT CHANGED");
				min=MIN=0;
				delay_ms(1000);
				Write_CMD_LCD(0x01);
				break;
		default:return;
				
	}

}

int main()
{
	unsigned char humidity_integer, humidity_decimal, temp_integer, temp_decimal, checksum;
	LCD_Init();
	rtc_init();
	InitKPM();
	Enable_EINT0();
	init_i2c();
	InitUART0();
	Write_CMD_LCD(0x01);
	Write_str_LCD("   MAJOR PROJECT   ");
	delay_ms(1000);
	esp01_connectAP();
	i2c_eeprom_write(I2C_SADDR,TEMP_ADDR,30);
	r_temp=i2c_eeprom_read(I2C_SADDR,TEMP_ADDR);
	i2c_eeprom_write(I2C_SADDR,HUMI_ADDR,45);
	r_humi=i2c_eeprom_read(I2C_SADDR,HUMI_ADDR);
	
	Write_CMD_LCD(0x01);
	min=MIN;
	while(1)
	{
		do
		{
			dht11_request();
			dht11_response();
			humidity_integer = dht11_data();
			humidity_decimal = dht11_data();
			temp_integer = dht11_data();
			temp_decimal = dht11_data();
			checksum = dht11_data();
			if( (humidity_integer + humidity_decimal + temp_integer + temp_decimal) != checksum )
				Write_str_LCD("Checksum Error\r\n");
			else
			{
				Write_CMD_LCD(0x80);
				Write_str_LCD("H : ");
				Write_int_LCD(humidity_integer);
				Write_DAT_LCD('.');
				Write_int_LCD(humidity_decimal);
				Write_str_LCD(" % RH ");
				Write_CMD_LCD(0xC0);
				Write_str_LCD("T : ");
				Write_int_LCD(temp_integer);
				Write_DAT_LCD('.');
				Write_int_LCD(temp_decimal);
				Write_DAT_LCD(223);
				Write_str_LCD("C");
				Write_CMD_LCD(0x94);
				Write_str_LCD("TEMP SPOINT: ");
				Write_int_LCD(r_temp);
				Write_DAT_LCD(223);
				Write_str_LCD("C");
				//Write_str_LCD(" % RH ");
				Write_CMD_LCD(0xD4);
				Write_str_LCD("HUMI SPOINT: ");
				Write_int_LCD(r_humi);
				Write_str_LCD(" % RH ");
		
				delay_ms(1000);
				//Write_CMD_LCD(0x01);
				if(min==MIN)
				{
					if(humidity_integer>r_humi)
					{
						esp01_sendToThingspeak(humidity_integer,2);
						delay_ms(1000);
					}
					if(temp_integer>r_temp)
					{
						esp01_sendToThingspeak(temp_integer,1);
					}
					min+=3;
				}
				if(MIN==59)
				min=0;
			}	
		}while(i_flag==0);
		i_flag=0;
		change_setpoint();
	}
}
