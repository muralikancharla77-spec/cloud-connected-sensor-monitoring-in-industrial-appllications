#include<LPC21xx.h>
#include"defines.h"
#include"types.h"
#include"kpm_defines.h"
#include"kpm.h"
#include "lcd.h"

u8 KpmLUT[4][4]={{'1','2','3','A'},
                   {'4','5','6','B'},
				   {'7','8','9','C'},
				   {'*','0','#','D'}};

void InitKPM(void)
{
   //cfg r0w lines AS GPIO OUT
   WRITENIBBLE(IODIR1,ROW0,15);
   //default col lines are any input
   //no cfg required
}
u32 ColScan(void)
{
   return ((READNIBBLE(IOPIN1,COL0)<15)?0:1);
}
u32 RowCheck(void)
{
   u32 rNo;
   for(rNo=0;rNo<=3;rNo++)
   {
      //ground one row at a time ,starting with 0th row
	  WRITENIBBLE(IOPIN1,ROW0,~(1<<rNo));
	  if(ColScan()==0)
	    break;
	}
	//re-initialize all rows to ground
	WRITENIBBLE(IOPIN1,ROW0,0);
	return rNo;
}
u32 ColCheck(void)
{
   u32 cNo;
   for(cNo=0;cNo<=3;cNo++)
   {
      if(READBIT(IOPIN1,COL0+cNo)==0)
	     break;
   }
   return cNo;
}
u8 KeyScan(void)
{
  u32 rNo,cNo,KeyV;
  //wait for any key press
  while(ColScan());
  //if any key pressed
  //identify row in which key was pressed
  rNo=RowCheck();
  cNo=ColCheck();
  KeyV=KpmLUT[rNo][cNo];
  return KeyV;
}
s32 ReadNum(void)
{
   static s32 sum=0;
   u8 keyC;
   sum=0;
   while(1)
   {
   keyC=KeyScan();
   delay_ms(200);
   if((keyC>='0')&&(keyC<='9'))
   {
      sum=(sum*10)+(keyC-48);
	  Write_CMD_LCD(0xc0);
	  Write_int_LCD(sum);
	  while(ColScan()==0);
	}
	else
	{
	  Write_CMD_LCD(0x01);
	  break;
	}
  }
  return sum;
}
